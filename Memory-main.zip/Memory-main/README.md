# Memory
Play the classic memory game with your favorite themes. Be as fast as possible and spare your clicks!
https://codepen.io/beumsk/pen/xdoKjX

TODO:
* other themes to add
* bigger memory choice
* dark theme
